package com.restaurant.mesa.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "reservas")
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "usuario_id", nullable = false)
    private Long usuarioId; // FK hacia Usuarios

    @Column(name = "mesa_id", nullable = false)
    private Long mesaId; // FK hacia Mesas

    @Column(nullable = false)
    private LocalDateTime fecha; // fecha y hora de la reserva

    @Column(nullable = false, length = 20)
    private String estado; // activa, cancelada, finalizada
}
