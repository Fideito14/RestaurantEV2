package com.restaurant.mesa.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MesaDTO {

    private Long id;

    @NotNull(message = "El numero de mesa es obligatorio")
    @Min(value = 1, message = "El numero de mesa debe ser mayor a 0")
    private Integer numero;

    @NotBlank(message = "El estado de la mesa es obligatorio")
    @Pattern(regexp = "libre|reservada|ocupada", message = "El estado de la mesa debe ser libre, reservada o ocupada")
    private String estado;


    private Long usuarioId;

}
