package com.restaurant.mesa.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI custOpenAPI(){
        return  new OpenAPI()
                .info(new Info()
                        .title("API Reserva de mesas")
                        .version("1.0")
                        .description("Documentacion de la API para el sistema de reserva de mesas"));
    }
}
