package com.restaurant.mesa.Service;

import com.restaurant.mesa.model.Mesa;
import com.restaurant.mesa.model.Reserva;
import com.restaurant.mesa.repository.MesaRepository;
import com.restaurant.mesa.repository.ReservaRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    private final MesaRepository mesaRepository;
    private final ReservaRepository reservaRepository;

    public DataLoader(MesaRepository mesaRepository, ReservaRepository reservaRepository) {
        this.mesaRepository = mesaRepository;
        this.reservaRepository = reservaRepository;
    }

    @Override
    public void run(String... args) {
        Faker faker = new Faker();
        Random random = new Random();

        // Generar mesas iniciales
        for (int i = 1; i <= 10; i++) {
            Mesa mesa = new Mesa();
            mesa.setNumero(i);
            mesa.setEstado("libre"); // todas empiezan libres
            mesa.setUsuarioId(null); // sin usuario asignado
            mesaRepository.save(mesa);
        }

        List<Mesa> mesas = mesaRepository.findAll();

        // Generar reservas de prueba
        for (int i = 0; i < 20; i++) {
            Mesa mesa = mesas.get(random.nextInt(mesas.size()));

            Reserva reserva = new Reserva();
            reserva.setUsuarioId((long) faker.number().numberBetween(1, 50)); // usuario ficticio
            reserva.setMesaId(mesa.getId());
            reserva.setFecha(LocalDateTime.now().plusDays(random.nextInt(5))); // reservas en los próximos días
            reserva.setEstado("Ocupada");

            reservaRepository.save(reserva);

            // actualizar estado de la mesa
            mesa.setEstado("reservado");
            mesa.setUsuarioId(reserva.getUsuarioId());
            mesaRepository.save(mesa);
        }
    }
}
