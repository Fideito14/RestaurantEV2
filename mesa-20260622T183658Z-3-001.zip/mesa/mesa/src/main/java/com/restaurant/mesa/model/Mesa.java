package com.restaurant.mesa.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mesas")
public class Mesa {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(nullable = false, unique = true)
        private Integer numero;

        @Column(nullable = false, length = 20)
        private String estado; // libre, reservado, ocupado

        @Column(name = "usuario_id")
        private Long usuarioId; // FK hacia Usuarios
}
