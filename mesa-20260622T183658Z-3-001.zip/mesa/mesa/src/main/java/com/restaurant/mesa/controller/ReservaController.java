package com.restaurant.mesa.controller;

import com.restaurant.mesa.dto.ReservaDTO;
import com.restaurant.mesa.Service.ReservaService;
import com.restaurant.mesa.model.Reserva;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reservas")
@Tag(name = "Reservas",description = "operaciones relacionadas con las reservas")
public class ReservaController {

    private final ReservaService reservaService;

    public ReservaController(ReservaService reservaService) {
        this.reservaService = reservaService;
    }

    //crear reserva
    @PutMapping("/reservas")
    @Operation(summary = "Crea una reserva", description =
            "Crea una reserva al instante!")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<Reserva> crearReserva(
            @RequestParam Long mesaId,
            @RequestParam Long usuarioId) {

        Reserva reserva = reservaService.crearReserva(mesaId, usuarioId);
        return ResponseEntity.ok(reserva);
    }


    // Cancelar reserva
    @PutMapping("/{id}/cancelar")
    @Operation(summary = "Cancelar reserva", description =
            "Cancela una reserva al instante!")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<ReservaDTO> cancelarReserva(@PathVariable Long id) {
        return reservaService.cancelarReserva(id)
                .map(reserva -> new ReservaDTO(
                        reserva.getId(),
                        reserva.getMesaId().intValue(),
                        reserva.getUsuarioId(),
                        reserva.getFecha(),
                        reserva.getEstado()
                ))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Finalizar reserva
    @PutMapping("/{id}/finalizar")
    @Operation(summary = "Finalizar reserva", description =
            "Finaliza una reserva al instante!")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<ReservaDTO> finalizarReserva(@PathVariable Long id) {
        return reservaService.finalizarReserva(id)
                .map(reserva -> new ReservaDTO(
                        reserva.getId(),
                        reserva.getMesaId().intValue(),
                        reserva.getUsuarioId(),
                        reserva.getFecha(),
                        reserva.getEstado()
                ))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Listar todas las reservas
    @GetMapping
    @Operation(summary = "Listar reservas", description =
            "Lista todas las reservas")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<List<ReservaDTO>> listarReservas() {
        List<ReservaDTO> reservas = reservaService.listarReservas().stream()
                .map(reserva -> new ReservaDTO(
                        reserva.getId(),
                        reserva.getMesaId().intValue(),
                        reserva.getUsuarioId(),
                        reserva.getFecha(),
                        reserva.getEstado()
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(reservas);
    }

    // Listar reservas por usuario
    @Operation(summary = "Listar por usuarios", description =
            "Lista todas las reservas ligadas a un usuario dado")
    @GetMapping("/usuario/{usuarioId}")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<List<ReservaDTO>> listarPorUsuario(@PathVariable Long usuarioId) {
        List<ReservaDTO> reservas = reservaService.listarReservasPorUsuario(usuarioId).stream()
                .map(reserva -> new ReservaDTO(
                        reserva.getId(),
                        reserva.getMesaId().intValue(),
                        reserva.getUsuarioId(),
                        reserva.getFecha(),
                        reserva.getEstado()
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(reservas);
    }

    // Listar reservas por mesa
    @GetMapping("/mesa/{mesaId}")
    @Operation(summary = "Listar por mesa", description =
            "Lista todas las reservas ligadas a un Id de mesa dada")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa"),
            @ApiResponse(responseCode = "404", description = "Carrera no encontrada")
    })
    public ResponseEntity<List<ReservaDTO>> listarPorMesa(@PathVariable Long mesaId) {
        List<ReservaDTO> reservas = reservaService.listarReservasPorMesa(mesaId).stream()
                .map(reserva -> new ReservaDTO(
                        reserva.getId(),
                        reserva.getMesaId().intValue(),
                        reserva.getUsuarioId(),
                        reserva.getFecha(),
                        reserva.getEstado()
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(reservas);
    }
}
