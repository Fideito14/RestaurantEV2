package com.restaurant.mesa.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.restaurant.mesa.Service.MesaService;
import com.restaurant.mesa.model.Mesa;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;

@WebMvcTest(MesaController.class)
public class MesaControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private MesaService mesaService;

    @Autowired
    private ObjectMapper objectMapper;

    private Mesa mesa;

    @BeforeEach
    void setUp(){
        mesa = new Mesa();
        mesa.setId(1L);
        mesa.setEstado("Libre");
        mesa.setNumero(1);
    }

    @Test
    public void testGetAllMesas() throws Exception {
        when(mesaService.findAll()).thenReturn(List.of(mesa));

        mockMvc.perform(get("/api/mesas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].Id").value(1L))
                .andExpect(jsonPath("$[0].Estado").value("Libre"))
                .andExpect(jsonPath("$[0].Numero").value(1));

    }
}
