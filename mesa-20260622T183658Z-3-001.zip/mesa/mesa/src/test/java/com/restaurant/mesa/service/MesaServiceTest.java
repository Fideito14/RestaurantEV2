package com.restaurant.mesa.service;

import com.restaurant.mesa.Service.MesaService;
import com.restaurant.mesa.model.Mesa;
import com.restaurant.mesa.repository.MesaRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@SpringBootTest
public class MesaServiceTest {

    @Autowired
    private MesaService mesaService;

    @MockitoBean
    private MesaRepository mesaRepository;

    @Test
    public void testFindAll() {
        when(mesaRepository.findAll()).thenReturn(List.of(new Mesa(1L,1,"Libre",null)));

        List<Mesa> salas = mesaService.findAll();
        assertNotNull(salas);
        assertEquals(1, salas.size());
    }
}
